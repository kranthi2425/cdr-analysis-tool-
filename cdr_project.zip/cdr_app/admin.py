from django.contrib import admin
from .models import CallDetailRecord

admin.site.register(CallDetailRecord)